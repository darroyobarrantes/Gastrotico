# -*- coding: utf-8 -*-
"""
Created on Wed Nov  2 23:03:38 2022

@author: fafec
"""


import os
import re
import csv
import time
import string
import numpy as np
import pandas as pd
from fuzzywuzzy import fuzz
from progress.bar import Bar
import pandas as pd
import Metodos as mt
from progress.bar import Bar
import time


regiones=["Pacifico_Central"]


termBusqueda = pd.read_csv("ListaC.csv", encoding='utf8')
tm=termBusqueda.to_numpy().tolist()
tem=[]
for t in tm:
    tem.append(t[0])
    





contenido = os.listdir("Reseñas/Central")

#df= pd.DataFrame(columns=["Zona"])
#dif=pd.DataFrame(columns=tem)


df= pd.DataFrame(columns=["Zona", "termino", "menciones"])
dif=pd.DataFrame(columns=tem)

for l in contenido:
    resena= pd.read_csv("Reseñas/Central/"+l, encoding='utf8')
    zona=l[7:-4]
    numMenciones = mt.iniciarContador(len(termBusqueda))
    n = 0
    
    
    bar1 = Bar(zona+':', max=len(termBusqueda))
    for indice, fila in termBusqueda.iterrows():
        term = fila[0].lower()
        i = 0
        for indice_fila, fila in resena.iterrows():
    
    
            n += 1
            comentario = fila["Comentario"]
            comentario = mt.deEmojify(comentario)
            

            if mt.comparation(comentario, term):
                numMenciones[indice] += 1
            
        df.loc[len(df.index)]=[zona, term, numMenciones[indice]]    
            
        i += 1
        time.sleep(0.000002)
        bar1.next()
    bar1.finish()    
    #df.loc[len(df.index)]=zona
    #dif.loc[len(dif.index)]=numMenciones
#dtf=pd.concat([df, dif], axis=1)   
    

#dtf.to_csv("match_terminos_localidad.csv")

df.to_csv("match_terminos_localidad.csv")


